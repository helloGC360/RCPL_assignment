<?php
session_start();

unset($_SESSION['user_id']);
unset($_SESSION['user_name']);

setcookie("user_email","",time()-3600,"/");

header("Location: login.php");
exit();
?>