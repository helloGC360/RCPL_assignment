<?php
session_start();
include("../config/db.php");

$error = "";

if(isset($_POST['register'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO users(name,email,password)
            VALUES('$name','$email','$password')";

    if($conn->query($sql)){
        header("Location: login.php");
        exit();
    } else {
        $error = "Registration Failed!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>User Register</title>
    <style>
        body{
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #36b9cc, #1cc88a);
            display:flex;
            justify-content:center;
            align-items:center;
            height:100vh;
            margin:0;
        }

        .card{
            background:white;
            padding:30px;
            border-radius:10px;
            width:350px;
            box-shadow:0 10px 25px rgba(0,0,0,0.2);
        }

        h2{
            text-align:center;
            margin-bottom:20px;
        }

        input{
            width:100%;
            padding:10px;
            margin:8px 0;
            border:1px solid #ccc;
            border-radius:5px;
        }

        button{
            width:100%;
            padding:10px;
            background:#36b9cc;
            color:white;
            border:none;
            border-radius:5px;
            cursor:pointer;
            font-size:16px;
        }

        button:hover{
            background:#2c9faf;
        }

        .error{
            color:red;
            text-align:center;
            margin-bottom:10px;
        }

        .login-link{
            text-align:center;
            margin-top:15px;
        }
    </style>
</head>
<body>

<div class="card">
    <h2>User Register</h2>

    <?php if($error){ ?>
        <p class="error"><?php echo $error; ?></p>
    <?php } ?>

    <form method="POST">
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>

        <button type="submit" name="register">Register</button>
    </form>

    <div class="login-link">
        Already have account? <a href="login.php">Login</a>
    </div>
</div>

</body>
</html>