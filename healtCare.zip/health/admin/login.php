<?php
session_start();
include("../config/db.php");

$error = "";

if(isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $result = $conn->query("SELECT * FROM admins WHERE email='$email'");
    
    if($result && $result->num_rows > 0){
        $admin = $result->fetch_assoc();

        if(password_verify($password,$admin['password'])){
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];

            setcookie("admin_email",$admin['email'],time()+3600,"/");

            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Invalid Password!";
        }
    } else {
        $error = "Admin not found!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <style>
        body{
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #1cc88a, #4e73df);
            display:flex;
            justify-content:center;
            align-items:center;
            height:100vh;
            margin:0;
        }

        .card{
            background:white;
            padding:30px;
            border-radius:10px;
            width:350px;
            box-shadow:0 10px 25px rgba(0,0,0,0.2);
        }

        h2{
            text-align:center;
            margin-bottom:20px;
        }

        input{
            width:100%;
            padding:10px;
            margin:8px 0;
            border:1px solid #ccc;
            border-radius:5px;
        }

        button{
            width:100%;
            padding:10px;
            background:#1cc88a;
            color:white;
            border:none;
            border-radius:5px;
            cursor:pointer;
            font-size:16px;
        }

        button:hover{
            background:#17a673;
        }

        .error{
            color:red;
            text-align:center;
            margin-bottom:10px;
        }

        .register-link{
            text-align:center;
            margin-top:15px;
        }
    </style>
</head>
<body>

<div class="card">
    <h2>Admin Login</h2>

    <?php if($error){ ?>
        <p class="error"><?php echo $error; ?></p>
    <?php } ?>

    <form method="POST">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>

        <button type="submit" name="login">Login</button>
    </form>

    <div class="register-link">
        Don't have account? <a href="register.php">Register</a>
    </div>
</div>

</body>
</html>