<?php
session_start();
include("../config/db.php");

if(!isset($_SESSION['admin_id'])){
    header("Location: login.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];
$admin = $conn->query("SELECT * FROM admins WHERE id='$admin_id'")->fetch_assoc();
$diseaseCount = $conn->query("SELECT * FROM diseases WHERE added_by='$admin_id'")->num_rows;
?>

<!DOCTYPE html>
<html>
<head>
<title>Doctor Dashboard</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family: 'Segoe UI', sans-serif;
}

body{
    display:flex;
    background:#f1f5f9;
}

/* Sidebar */

.sidebar{
    width:250px;
    height:100vh;
    background:#0f172a;
    color:white;
    padding:20px;
    position:fixed;
}

.sidebar h2{
    margin-bottom:30px;
    font-size:22px;
    text-align:center;
}

.sidebar a{
    display:block;
    color:#cbd5e1;
    text-decoration:none;
    padding:12px;
    border-radius:6px;
    margin-bottom:10px;
    transition:0.3s;
}

.sidebar a:hover{
    background:#1e293b;
    color:white;
}

/* Main Content */

.main{
    margin-left:250px;
    width:100%;
    padding:30px;
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:30px;
}

.profile-card{
    background:white;
    padding:25px;
    border-radius:12px;
    box-shadow:0 10px 25px rgba(0,0,0,0.08);
    display:flex;
    align-items:center;
    gap:20px;
}

.profile-card img{
    width:100px;
    height:100px;
    border-radius:50%;
    object-fit:cover;
    border:3px solid #3b82f6;
}

.info h3{
    margin-bottom:5px;
}

.stats-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
    gap:20px;
    margin-top:30px;
}

.stat-box{
    background:white;
    padding:20px;
    border-radius:10px;
    box-shadow:0 8px 20px rgba(0,0,0,0.05);
}

.stat-box h4{
    color:#64748b;
    margin-bottom:10px;
}

.stat-number{
    font-size:28px;
    font-weight:bold;
    color:#2563eb;
}

.btn{
    display:inline-block;
    padding:10px 18px;
    background:#2563eb;
    color:white;
    text-decoration:none;
    border-radius:6px;
    transition:0.3s;
}

.btn:hover{
    background:#1d4ed8;
}

.logout{
    color:#ef4444;
}

</style>
</head>

<body>

<!-- Sidebar -->
<div class="sidebar">
    <h2>🏥 Health Panel</h2>
    <a href="dashboard.php">Dashboard</a>
    <a href="add_disease.php">Create Disease</a>
    <a href="#" class="logout">Reports</a>
    <a href="logout.php" class="logout">Logout</a>
</div>

<!-- Main -->
<div class="main">

    <div class="header">
        <h1>Doctor Dashboard</h1>
        <a href="add_disease.php" class="btn">+ Add Disease</a>
    </div>

    <div class="profile-card">
        <?php if(!empty($admin['profile_url'])): ?>
            <img src="<?php echo $admin['profile_url']; ?>">
        <?php else: ?>
            <img src="https://via.placeholder.com/100">
        <?php endif; ?>

        <div class="info">
            <h3>Dr. <?php echo $admin['name']; ?></h3>
            <p><?php echo $admin['email']; ?></p>
            <p><?php echo $admin['location']; ?></p>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-box">
            <h4>Total Diseases Added</h4>
            <div class="stat-number"><?php echo $diseaseCount; ?></div>
        </div>

        <div class="stat-box">
            <h4>Status</h4>
            <div class="stat-number">Active</div>
        </div>

        <div class="stat-box">
            <h4>System Role</h4>
            <div class="stat-number">Doctor</div>
        </div>
    </div>

</div>

</body>
</html>