<?php
session_start();

unset($_SESSION['admin_id']);
unset($_SESSION['admin_name']);

setcookie("admin_email","",time()-3600,"/");

header("Location: login.php");
exit();
?>