<?php
session_start();
include("../config/db.php");

if(!isset($_SESSION['admin_id'])){
    header("Location: login.php");
    exit();
}

$message = "";

if(isset($_POST['add'])){
    $name = $_POST['disease'];
    $symptoms = $_POST['symptoms'];
    $description = $_POST['description'];
    $admin_id = $_SESSION['admin_id'];

    $conn->query("INSERT INTO diseases(disease_name,symptoms,description,added_by)
                  VALUES('$name','$symptoms','$description','$admin_id')");

    $message = "Disease Added Successfully!";
}
?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create Disease</title>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family: 'Segoe UI', sans-serif;
    background: linear-gradient(135deg,#667eea,#764ba2);
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:20px;
}

/* Glass Card */
.card{
    background: rgba(255,255,255,0.15);
    backdrop-filter: blur(15px);
    border-radius:15px;
    padding:40px;
    width:100%;
    max-width:550px;
    box-shadow:0 20px 40px rgba(0,0,0,0.3);
    color:white;
    animation: fadeIn 0.6s ease-in-out;
}

@keyframes fadeIn{
    from{opacity:0; transform:translateY(20px);}
    to{opacity:1; transform:translateY(0);}
}

h2{
    text-align:center;
    margin-bottom:25px;
    font-weight:600;
    letter-spacing:1px;
}

/* Input Styling */
input, textarea{
    width:100%;
    padding:12px 15px;
    margin:10px 0;
    border-radius:8px;
    border:none;
    outline:none;
    font-size:14px;
    transition:0.3s;
}

input:focus, textarea:focus{
    box-shadow:0 0 0 2px #fff;
}

textarea{
    resize:none;
    height:100px;
}

/* Button */
button{
    width:100%;
    padding:12px;
    margin-top:15px;
    border:none;
    border-radius:8px;
    background:#ffffff;
    color:#4c51bf;
    font-weight:600;
    font-size:16px;
    cursor:pointer;
    transition:0.3s;
}

button:hover{
    background:#e2e8f0;
    transform:translateY(-2px);
}

/* Message */
.msg{
    background:#16a34a;
    padding:10px;
    border-radius:6px;
    text-align:center;
    margin-bottom:10px;
    font-size:14px;
}

/* Back Link */
.back{
    display:block;
    margin-top:20px;
    text-align:center;
    text-decoration:none;
    color:#fff;
    font-size:14px;
    opacity:0.8;
}

.back:hover{
    opacity:1;
}

/* Responsive */
@media(max-width:500px){
    .card{
        padding:25px;
    }
    h2{
        font-size:20px;
    }
}

</style>
</head>

<body>

<div class="card">

    <h2>🩺 Create New Disease</h2>

    <?php if($message){ ?>
        <div class="msg"><?php echo $message; ?></div>
    <?php } ?>

    <form method="POST">
        <input type="text" name="disease" placeholder="Disease Name" required>

        <textarea name="symptoms" placeholder="Symptoms (comma separated)" required></textarea>

        <textarea name="description" placeholder="Disease Description" required></textarea>

        <button type="submit" name="add">Save Disease</button>
    </form>

    <a href="dashboard.php" class="back">← Back to Dashboard</a>

</div>

</body>
</html>